import Picker from './picker/picker';

/* eslint-disable no-undef */
Picker.version = __VERSION__;

export default Picker;
